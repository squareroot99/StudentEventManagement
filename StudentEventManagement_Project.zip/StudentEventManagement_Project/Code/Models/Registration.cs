namespace StudentEventManagement.Models;

public class Registration
{
    public int RegistrationId { get; set; }
    public int StudentId { get; set; }
    public int EventId { get; set; }
    public DateTime RegistrationDate { get; set; } = DateTime.Now;
    public Student? Student { get; set; }
    public Event? Event { get; set; }
}