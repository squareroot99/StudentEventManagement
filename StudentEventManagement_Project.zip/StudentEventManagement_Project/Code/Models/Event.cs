namespace StudentEventManagement.Models;

public class Event
{
    public int EventId { get; set; }
    public string EventName { get; set; } = "";
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = "";
    public string? Description { get; set; }
    public int Capacity { get; set; }
    public List<Registration> Registrations { get; set; } = new();
}