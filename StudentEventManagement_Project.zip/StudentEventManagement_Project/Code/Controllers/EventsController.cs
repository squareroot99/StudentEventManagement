using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentEventManagement.Data;
using StudentEventManagement.Models;

namespace StudentEventManagement.Controllers;

public class EventsController : Controller
{
    private readonly AppDbContext _db;
    public EventsController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Index()
        => View(await _db.Events.Include(e => e.Registrations).ToListAsync());

    [HttpGet]
    public IActionResult Register(int id) => View(new Registration { EventId = id });

    [HttpPost]
    public async Task<IActionResult> Register(Registration registration)
    {
        var ev = await _db.Events.Include(e => e.Registrations)
            .FirstOrDefaultAsync(e => e.EventId == registration.EventId);

        if (ev == null) return NotFound();

        if (ev.Registrations.Count >= ev.Capacity)
        {
            ModelState.AddModelError("", "This event is full.");
            return View(registration);
        }

        var student = await _db.Students
            .FirstOrDefaultAsync(s => s.Email == registration.Student!.Email);

        if (student == null)
        {
            student = new Student
            {
                Name = registration.Student!.Name,
                Email = registration.Student.Email
            };
            _db.Students.Add(student);
            await _db.SaveChangesAsync();
        }

        if (await _db.Registrations.AnyAsync(r =>
            r.EventId == ev.EventId && r.StudentId == student.StudentId))
        {
            ModelState.AddModelError("", "You are already registered for this event.");
            return View(registration);
        }

        _db.Registrations.Add(new Registration
        {
            EventId = ev.EventId,
            StudentId = student.StudentId,
            RegistrationDate = DateTime.Now
        });
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }
}