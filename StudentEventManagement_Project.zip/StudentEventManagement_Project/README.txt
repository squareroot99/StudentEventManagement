StudentEventManagement – Small Student Assignment

Contents:
1. Project Charter
2. Requirements Specification
3. Acceptance Criteria
4. Database Design
5. Code starter for Visual Studio / ASP.NET Core MVC

How to start:
1. Open the .csproj file in Visual Studio 2022.
2. Restore NuGet packages.
3. Create StudentEventManagementDB using the SQL script in Database Design.
4. Check the connection string in appsettings.json.
5. Add MVC Create/Edit/Delete pages if required by your instructor.
6. Run the project.

This is intentionally small and suitable as a student project starter. The registration and event-list features are included; administrator CRUD can be completed using the same MVC pattern.
