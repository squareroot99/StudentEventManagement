---
name: Collegiate Event Nexus
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#444651'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#002f38'
  on-tertiary: '#ffffff'
  tertiary-container: '#004754'
  on-tertiary-container: '#1dbcda'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  container-max: 80rem
---

## Brand & Style

The design system establishes a clean, contemporary, and approachable academic SaaS visual language. Crafted for a university campus ecosystem, it balances collegiate authority with the fresh, energetic pulse of student life. The interface prioritizes clarity, intuitive navigation, and effortless event discovery across student unions, academic departments, clubs, and athletic associations.

The aesthetic fuses **Corporate / Modern SaaS** precision with subtle, warm academic cues. It rejects bureaucratic institutional clutter in favor of airy layouts, structured white elevated cards, purposeful color coding, and high-legibility typography. Interfaces must evoke feelings of capability, organization, anticipation, and belonging—making campus engagement feel accessible rather than administrative.

## Colors

The palette balances formal collegiate gravitas with youthful engagement. 

- **Primary (`#1E3A8A`)**: Deep Collegiate Navy anchors navigation bars, primary calls-to-action, active tabs, and primary headings. An interactive hover state is derived at `#1D4ED8`.
- **Secondary Accent (`#0D9488`)**: Energetic Teal serves as the interactive compliment—used for student club badges, featured event ribbons, and key progress meters.
- **Tertiary Cyan (`#06B6D4`)**: A vibrant cyan supporting secondary data visualizations, metric counters, and informational highlights.
- **Neutral Palette**: Grounded on a crisp slate scale. The page canvas rests on `#F8FAFC`, elevated containers on `#FFFFFF`, structural borders on `#E2E8F0`, muted secondary text on `#64748B`, and primary text on deep slate `#0F172A`.
- **Feedback & State Semantics**:
  - *Success / Available*: `#16A34A` (Background: `#DCFCE7`, Border: `#86EFAC`)
  - *Warning / Almost Full*: `#D97706` (Background: `#FEF3C7`, Border: `#FCD34D`)
  - *Danger / Full / Cancelled*: `#DC2626` (Background: `#FEE2E2`, Border: `#FCA5A5`)

## Typography

The typographic hierarchy leverages **Plus Jakarta Sans** for headlines and interactive component labels to inject a friendly, welcoming, contemporary academic feel, and **Inter** for dense transactional UI, forms, and general body copy to guarantee optimal reading cadence.

- Line lengths for event descriptions and notices are kept between 55–75 characters.
- Headings maintain subtle negative letter-spacing for tight visual cohesion at larger sizes.
- Micro-labels, badge text, and metric counters strictly utilize `label-md` and `label-sm` with slight positive tracking to ensure effortless scanning against contrasting badge fills.

## Layout & Spacing

The design system relies on a responsive, 12-column fluid-hybrid grid system bounded by a maximum content container width of `80rem` (1280px). Layout structure and margins adapt systematically across standard device viewports:

- **Mobile (< 768px)**: 4-column layout with `1rem` (16px) edge margins and gutters. Views stack into a single column; complex event tables collapse into card-list formats.
- **Tablet (768px – 1023px)**: 8-column layout with `1.5rem` (24px) gutters and margins. Side navigation shifts to a collapsible off-canvas drawer.
- **Desktop (1024px+)**: 12-column layout with `1.5rem` (24px) gutters and `2rem` (32px) margins. Standard structure deploys a 2- or 3-column split for persistent filtering/navigation alongside the primary event feed.

Vertical rhythms stick to an 8px base rhythm (`0.5rem`, `1rem`, `1.5rem`, `2rem`), maintaining clean separation between registration modules, schedules, and administrative summaries.

## Elevation & Depth

Visual depth is achieved through high-contrast card separation on a soft canvas (`#F8FAFC`), crisp hair-thin borders, and delicate ambient drop shadows tinted with navy undertones.

- **Level 0 (Flat Canvas)**: `#F8FAFC` — Base page surface. No shadow.
- **Level 1 (Default Containers & Standard Cards)**: Pure white `#FFFFFF` surface resting on a structural `1px solid #E2E8F0` border, lifted by `shadow-sm` (`0 1px 2px 0 rgba(30, 58, 138, 0.04)`).
- **Level 2 (Interactive Hover / Highlighted Event Cards)**: Active card elevation transitions smoothly via CSS on pointer hover, deploying `shadow-md` (`0 4px 6px -1px rgba(30, 58, 138, 0.08), 0 2px 4px -2px rgba(30, 58, 138, 0.04)`) with an accompanying border color shift to `#CBD5E1`.
- **Level 3 (Modals, Overlays, Dropdowns)**: Pure white `#FFFFFF` surface paired with `shadow-xl` (`0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`), overlaid across an accessible scrim (`rgba(15, 23, 42, 0.4)` backdrop blur of `4px`).

## Shapes

The geometric identity is defined by a modern, approachable roundedness level. 

- Standard interactive elements (inputs, select menus, small action buttons) inherit `rounded-md` (`0.375rem` / 6px) to `rounded-lg` (`0.5rem` / 8px).
- Content cards, dashboard panels, and modal dialogues consistently employ `rounded-xl` (`0.75rem` to `1rem` / 12px to 16px) to foster a clean, soft SaaS ambiance.
- Badges, status chips, and avatar containers utilize pill geometries (`rounded-full` / 9999px) to establish visual contrast against rectangular layouts.

## Components

### Buttons
- **Primary**: Solid Navy (`#1E3A8A`), white text (`#FFFFFF`), `rounded-lg` (8px), padding `0.625rem 1.25rem`. Hover: `#1D4ED8`. Focus: `2px solid #FFFFFF` with an outer `2px solid #1D4ED8` offset ring.
- **Secondary**: Solid Teal (`#0D9488`), white text (`#FFFFFF`), hover: `#0F766E`.
- **Outline / Neutral**: White surface, `#E2E8F0` border, `#1E3A8A` text. Hover: `#F1F5F9`.

### Availability Status Badges (Pills)
Constructed with `label-sm`, uppercase formatting, `rounded-full`, and internal padding `0.25rem 0.625rem`:
- **Available**: Soft green background (`#DCFCE7`), deep green text (`#15803D`), border `1px solid #86EFAC`. Includes a `6px` solid green indicator dot.
- **Almost Full**: Soft amber background (`#FEF3C7`), dark amber text (`#B45309`), border `1px solid #FCD34D`.
- **Full / Closed**: Soft red background (`#FEE2E2`), dark red text (`#B91C1C`), border `1px solid #FCA5A5`.

### Event Cards
- Surface: `#FFFFFF`, `rounded-xl` (16px), `1px solid #E2E8F0`, `shadow-sm`.
- Interior Padding: `1.25rem` (20px).
- Behavior: Smooth `translate-y(-2px)` transition with `shadow-md` on hover. Top ribbon or top-right badge displays dynamic event capacity status.

### Form Inputs & Select Controls (ASP.NET Core TagHelpers Ready)
- Height: `2.625rem` (42px), `rounded-lg`, border `1px solid #CBD5E1`, background `#FFFFFF`.
- Typography: Inter 14px (`body-md`), text `#0F172A`. Placeholder: `#94A3B8`.
- Focus State: Unambiguous accessibility compliance with border color transitioning to `#1E3A8A` and an expansive focus ring (`box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.15)`).
- Validation State: `.input-validation-error` maps to border `#DC2626` with ring `rgba(220, 38, 38, 0.15)`.

### Selection Controls (Checkboxes & Radios)
- Checkboxes: `1.125rem` square, `rounded` (4px), border `1.5px solid #CBD5E1`. Checked: `#1E3A8A` fill with white checkmark SVG.
- Radios: `1.125rem` circular, border `1.5px solid #CBD5E1`. Selected: `#1E3A8A` border containing centered `#1E3A8A` solid bullet dot.

### Specialized Event Components
- **Capacity Progress Bar**: `0.5rem` (8px) height track (`#F1F5F9`), `rounded-full` fill utilizing `#0D9488` when normal, shifting automatically to `#D97706` past 80% capacity and `#DC2626` at 100%.
- **Date Badge**: Square calendar block, top navy header indicating 3-letter month (`#1E3A8A`), white bottom housing bold day number (`20px`, `700`).